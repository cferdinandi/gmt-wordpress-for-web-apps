<?php
/*
Plugin Name: No Admin Panel Access
Description: Prevents non-admin users from accessing to the Admin Panel/Dashboard (aka the backend)
Version: 0.1
License: GPL
Author: Chris Ferdinandi
Author URI: http://gomakethings.com

One side-effect of this plugin: If you're not logged in, visiting YourSiteURL.com/wp-admin will redirect you to the homepage.
You will need to login using YourSiteURL.com/wp-login.php.

Code by Gary Pendergast at http://pento.net/2011/06/19/preventing-users-from-accessing-wp-admin/
*/

add_action( 'init', 'blockusers_init' );
function blockusers_init() {
	// If accessing the admin panel and not an admin...
	if ( is_admin() && !current_user_can('level_10') ) {
		// Redirect to the homepage
		wp_redirect( home_url() );
		exit;
	}
}

?>
