Plugin Name: No Admin Panel Access
Version: 0.1
License: GPL
Author: Chris Ferdinandi
Author URI: http://gomakethings.com

Prevents non-admin users from accessing to the Admin Panel/Dashboard (aka the backend). One side-effect of this plugin: If you're not logged in, visiting YourSiteURL.com/wp-admin will redirect you to the homepage. You will need to login using YourSiteURL.com/wp-login.php.

Code by Gary Pendergast at http://pento.net/2011/06/19/preventing-users-from-accessing-wp-admin/.


== Installation ==

1. Upload the 'no-admin-panel-access' folder to the '/wp-content/plugins/' directory. (For ease of use, you may prefer to upload the zipped version through WordPress's built-in installer.)
2. Activate the plugin through the 'Plugins' menu in WordPress
3. That's it!