Plugin Name: Disable Admin Bar
Version: 0.1
License: GPL
Author: Chris Ferdinandi
Author URI: http://gomakethings.com

Disables the Admin Bar for all users.


== Installation ==

1. Upload the 'gmt-disable-admin-bar' folder to the '/wp-content/plugins/' directory. (For ease of use, you may prefer to upload the zipped version through WordPress's built-in installer.)
2. Activate the plugin through the 'Plugins' menu in WordPress
3. That's it!