<?php
/*
Plugin Name: GMT Disable Admin Bar
Description: Disables the admin bar for all users
Version: 0.1
License: GPL
Author: Chris Ferdinandi
Author URI: http://gomakethings.com
*/

function my_function_admin_bar(){
    return false;
}
add_filter( 'show_admin_bar' , 'my_function_admin_bar');

?>
