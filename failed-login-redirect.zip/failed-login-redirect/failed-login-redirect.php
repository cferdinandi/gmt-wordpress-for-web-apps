<?php
/*
Plugin Name: Failed Login Redirect
Description: Override default redirect to WordPress backend on failed login
Version: 0.1
License: GPL
Author: Chris Ferdinandi
Author URI: http://gomakethings.com

Code by BB Press at http://bbpress.org/forums/topic/empty-login-submissions-go-to-wp-login-php-page/
*/

add_action('login_redirect', 'redirect_login', 10, 3);
function redirect_login($redirect_to, $url, $user) {
	// Get the reffering page, where did the post submission come from?
	$referrer = $_SERVER['HTTP_REFERER'];
	// Redirect back to login screen, with error message (change URL as needed)
	$redirect =  home_url('/login/?login=failed');
	// Redirect home
	$home = home_url();

	// If the post submission is a valid page that's not the backend login screen, do the following...
	if(!empty($referrer) && !strstr($referrer,'wp-login') && !strstr($referrer,'wp-admin')){
		// If the password is empty...
		if($user->errors['empty_password']){
			wp_redirect($redirect);
		}
		// If the username is empty...
		else if($user->errors['empty_username']){
			wp_redirect($redirect);
		}
		// If the username is invalid...
		else if($user->errors['invalid_username']){
			wp_redirect($redirect);
		}
		// If the password is incorrect...
		else if($user->errors['incorrect_password']){
			wp_redirect($redirect);
		}
		// Catch all for all other issues
		else{
			wp_redirect($redirect);
		}
		exit;
	}

}

?>
