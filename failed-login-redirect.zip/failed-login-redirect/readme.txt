Plugin Name: Failed Login Redirect
Version: 0.1
License: GPL
Author: Chris Ferdinandi
Author URI: http://gomakethings.com

Override default redirect to WordPress backend on failed login.

Code by BB Press at http://bbpress.org/forums/topic/empty-login-submissions-go-to-wp-login-php-page/.


== Installation ==

1. Upload the 'failed-login-redirect' folder to the '/wp-content/plugins/' directory. (For ease of use, you may prefer to upload the zipped version through WordPress's built-in installer.)
2. Activate the plugin through the 'Plugins' menu in WordPress
3. That's it!