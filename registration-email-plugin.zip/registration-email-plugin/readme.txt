Plugin Name: Custom Registration Email
Version: 0.1
License: GPL
Author: Chris Ferdinandi
Author URI: http://gomakethings.com

Customize the registration email that WordPress sends to new users.

Code by Ohad Raz (http://en.bainternet.info/about) from StackExchange (http://wordpress.stackexchange.com/questions/15304/how-to-change-the-default-registration-email-plugin-and-or-non-plugin).


== Installation ==

1. Upload the 'registration-email-plugin' folder to the '/wp-content/plugins/' directory. (For ease of use, you may prefer to upload the zipped version through WordPress's built-in installer.)
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Click on 'Edit' from the 'Plugins' menu to modify the email language, and click 'Update' when you're finished.
4. That's it!