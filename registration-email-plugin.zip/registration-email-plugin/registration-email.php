<?php
/*
Plugin Name: Custom Registration Email
Description: Changes the default language of the new user registration email
Version: 0.1
License: GPL
Author: Chris Ferdinandi
Author URI: http://gomakethings.com

Code by Ohad Raz (http://en.bainternet.info/about) from StackExchange (http://wordpress.stackexchange.com/questions/15304/how-to-change-the-default-registration-email-plugin-and-or-non-plugin).
*/

// If wp_new_user_notification function does not already exist
if ( !function_exists('wp_new_user_notification') ) {
	// Create wp_new_user_notification function
	function wp_new_user_notification( $user_id, $plaintext_pass = '' ) {

		// Define new user variables
		$user = new WP_User($user_id);
		$user_login = stripslashes($user->user_login);
		$user_email = stripslashes($user->user_email);

		// Create email with new user login info
		$message  = sprintf(__('New user registration for %s:'), get_option('blogname')) . "\r\n\r\n";
		$message .= sprintf(__('Username: %s'), $user_login) . "\r\n\r\n";
		$message .= sprintf(__('E-mail: %s'), $user_email) . "\r\n";

		// Process WordPress email function
		@wp_mail(get_option('admin_email'), sprintf(__('[%s] New User Registration'), get_option('blogname')), $message);

		if ( empty($plaintext_pass) )
			return;

			// Message to include with login info. Can be customized.
			$message  = __('Hi,') . "\r\n\r\n";
			$message .= sprintf(__("Welcome to %s! Here's how to log in:"), get_option('blogname')) . "\r\n\r\n";
			$message .= wp_login_url() . "\r\n";
			$message .= sprintf(__('Username: %s'), $user_login) . "\r\n";
			$message .= sprintf(__('Password: %s'), $plaintext_pass) . "\r\n\r\n";
			$message .= sprintf(__('If you have any problems, please contact me at %s.'), get_option('admin_email')) . "\r\n\r\n";
			$message .= __('Adios!');

		// Send email
		wp_mail($user_email, sprintf(__('[%s] Your username and password'), get_option('blogname')), $message);

	}
}

?>
