Plugin Name: CDN Hosted jQuery
Version: 0.1
License: GPL
Author: Chris Ferdinandi
Author URI: http://gomakethings.com

Uses the CDN hosted version of jQuery instead of the one built into WordPress.


== Installation ==

1. Upload the 'cdn-hosted-jquery' folder to the '/wp-content/plugins/' directory. (For ease of use, you may prefer to upload the zipped version through WordPress's built-in installer.)
2. Activate the plugin through the 'Plugins' menu in WordPress
3. That's it!