<?php
/*
Plugin Name: CDN Hosted jQuery
Description: Uses a CDN hosted version of jQuery instead of the WordPress default.
Version: 0.1
License: GPL
Author: Chris Ferdinandi
Author URI: http://gomakethings.com
*/

function my_scripts_method() {
    // Deregisters built-in version of jQuery
	wp_deregister_script('jquery'); 
    // Automatically pulls the most recent, stable version of jQuery
	wp_register_script('jquery', 'http://code.jquery.com/jquery.min.js', false, null); 
	wp_enqueue_script('jquery');

}

add_action('wp_enqueue_scripts', 'my_scripts_method');

?>
